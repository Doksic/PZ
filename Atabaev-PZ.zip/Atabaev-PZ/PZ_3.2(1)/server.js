const express = require('express');
const fs = require('fs');
const path = require('path');
const moment = require('moment-timezone');
const requestIp = require('request-ip');
const app = express();
const port = 3000;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});


app.post('/save-client', (req, res) => {
  
    let clientIp = requestIp.getClientIp(req) || 'unknown';

    if (clientIp === '::1') {
        clientIp = '127.0.0.1'; 
    } else if (clientIp.startsWith('::ffff:')) {
        clientIp = clientIp.replace('::ffff:', '');
    }

    const clientPort = req.socket.remotePort || 'unknown';

    const requestDate = moment().tz('Europe/Kyiv').format('YYYY-MM-DD HH:mm:ss');
    
    const clientData = {
        ip: clientIp,
        port: clientPort,
        date: requestDate
    };

   
    const filePath = path.join(__dirname, 'skam.json');

    let existingData = [];
    if (fs.existsSync(filePath)) {
        const fileContent = fs.readFileSync(filePath, 'utf8');
        
        if (fileContent.trim() !== '') {
            let parsedData;
            try {
                parsedData = JSON.parse(fileContent);
            } catch (e) {
                parsedData = null;
            }
            if (parsedData && Array.isArray(parsedData)) {
                existingData = parsedData;
            }
        }
    } else {
        
        fs.writeFileSync(filePath, JSON.stringify([], null, 2));
    }

    existingData.push(clientData);
    fs.writeFileSync(filePath, JSON.stringify(existingData, null, 2));
});
app.listen(port, () => {
    console.log(`Сервер запущено на http://localhost:${port}`);
});