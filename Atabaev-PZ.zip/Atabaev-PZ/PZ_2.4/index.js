const fs = require('fs').promises; 
const path = require('path');
const readline = require('readline');
const EventEmitter = require('events');


class FileManager extends EventEmitter {
    constructor() {
        super();
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
        this.workingDir = process.cwd(); 
    }

  
    showMenu() {
        console.log(`
Виберіть дію:
1 - Створити файл
2 - Створити каталог
3 - Читати файл
4 - Читати каталог
5 - Оновити файл (додати текст)
6 - Перейменувати файл/каталог
7 - Видалити файл
8 - Видалити каталог
9 - Вийти
        `);
    }

    
    async promptAction() {
        return new Promise((resolve) => {
            this.rl.question('Введіть номер дії: ', resolve);
        });
    }

    async promptName(promptText) {
        return new Promise((resolve) => {
            this.rl.question(promptText, resolve);
        });
    }

 
    async promptText() {
        return new Promise((resolve) => {
            this.rl.question('Введіть текст для додавання: ', resolve);
        });
    }

    
    async start() {
        while (true) {
            this.showMenu();
            const action = await this.promptAction();

            switch (action) {
                case '1':
                    const fileName = await this.promptName('Введіть назву файлу: ');
                    this.emit('createFile', fileName);
                    break;

                case '2': 
                    const dirName = await this.promptName('Введіть назву каталогу: ');
                    this.emit('createDir', dirName);
                    break;

                case '3': 
                    const fileToRead = await this.promptName('Введіть назву файлу для читання: ');
                    this.emit('readFile', fileToRead);
                    break;

                case '4': 
                    const dirToRead = await this.promptName('Введіть назву каталогу (або . для поточного): ');
                    this.emit('readDir', dirToRead || '.');
                    break;

                case '5': 
                    const fileToUpdate = await this.promptName('Введіть назву файлу для оновлення: ');
                    const text = await this.promptText();
                    this.emit('updateFile', fileToUpdate, text);
                    break;

                case '6':
                    const oldName = await this.promptName('Введіть поточну назву файлу/каталогу: ');
                    const newName = await this.promptName('Введіть нову назву: ');
                    this.emit('rename', oldName, newName);
                    break;

                case '7': 
                    const fileToDelete = await this.promptName('Введіть назву файлу для видалення: ');
                    this.emit('deleteFile', fileToDelete);
                    break;

                case '8': 
                    const dirToDelete = await this.promptName('Введіть назву каталогу для видалення: ');
                    this.emit('deleteDir', dirToDelete);
                    break;

                case '9':
                    this.emit('exit');
                    return;

                default:
                    console.log('Невірна дія! Виберіть число від 1 до 9.');
            }
        }
    }
}


const fileManager = new FileManager();


fileManager.on('createFile', async (fileName) => {
   
        const filePath = path.join(fileManager.workingDir, fileName);
        await fs.writeFile(filePath, '');
        console.log(`"${fileName}" створено успішно!`);

});

fileManager.on('createDir', async (dirName) => {
   
        const dirPath = path.join(fileManager.workingDir, dirName);
        await fs.mkdir(dirPath);
        console.log(`"${dirName}" створено успішно!`);
  
});

fileManager.on('readFile', async (fileName) => {
   
        const filePath = path.join(fileManager.workingDir, fileName);
        const content = await fs.readFile(filePath, 'utf8');
        console.log(`Вміст файлу "${fileName}":\n${content}`);
    
});

fileManager.on('readDir', async (dirName) => {
 
        const dirPath = path.join(fileManager.workingDir, dirName);
        const items = await fs.readdir(dirPath);
        console.log(` Вміст каталогу "${dirName}":\n${items.join('\n')}`);
   
});

fileManager.on('updateFile', async (fileName, text) => {
   
        const filePath = path.join(fileManager.workingDir, fileName);
        await fs.appendFile(filePath, text + '\n');
        console.log(`Файл "${fileName}" оновлено успішно!`);
   
});

fileManager.on('rename', async (oldName, newName) => {
   
        const oldPath = path.join(fileManager.workingDir, oldName);
        const newPath = path.join(fileManager.workingDir, newName);
        await fs.rename(oldPath, newPath);
        console.log(` "${oldName}" перейменовано на "${newName}" успішно!`);
   
});

fileManager.on('deleteFile', async (fileName) => {
   
        const filePath = path.join(fileManager.workingDir, fileName);
        await fs.unlink(filePath);
        console.log(` Файл "${fileName}" видалено успішно!`);
 
});

fileManager.on('deleteDir', async (dirName) => {
    
        const dirPath = path.join(fileManager.workingDir, dirName);
        await fs.rm(dirPath, { recursive: true });
        console.log(` Каталог "${dirName}" видалено успішно!`);
   
});

fileManager.on('exit', () => {
    console.log('Програма завершена.');
    fileManager.rl.close();
});

fileManager.start();