const express = require('express');
const fs = require('fs').promises;
const path = require('path');

const app = express();
const PORT = 3000;


app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname)));


const saveResultsMiddleware = async (req, res, next) => {
    if (req.method === 'POST' && req.path === '/results') {
      
            let { user, answers } = req.body;

            
            if (user === '<!--USER-->') {
                throw new Error('Помилка: ім’я користувача не було замінено');
            }

            const questions = JSON.parse(await fs.readFile('test.json', 'utf-8'));
            let score = 0;

            
            const results = questions.map((q, index) => {
                const userAnswer = parseInt(answers[index]);
                const isCorrect = userAnswer === q.correct;
                if (isCorrect) score++;
                return {
                    question: q.question,
                    options: q.options,
                    userAnswer,
                    correctAnswer: q.correct,
                    isCorrect
                };
            });

            
            const resultEntry = {
                user,
                total: questions.length,
                score
            };

            
            console.log('Запис у results.json:', resultEntry);

           
            let allResults = [];
           
                const fileContent = await fs.readFile('results.json', 'utf-8');
                allResults = JSON.parse(fileContent);
           

           
            allResults.push(resultEntry);
            await fs.writeFile('results.json', JSON.stringify(allResults, null, 2));

            
            req.results = { user, score, total: questions.length, answers: results };
       
    }
    next();
};


app.use(saveResultsMiddleware);

app.get('/', async (req, res) => {
 
        const loginPage = await fs.readFile(path.join(__dirname, 'pages', 'login.html'), 'utf-8');
        res.send(loginPage);
   
});


app.post('/test', async (req, res) => {
   
        const { firstName } = req.body;
        const user = `${firstName}`;
        const questions = JSON.parse(await fs.readFile('test.json', 'utf-8'));

        
        let testPage = await fs.readFile(path.join(__dirname, 'pages', 'test.html'), 'utf-8');

        let questionsHTML = '';
        questions.forEach((q, index) => {
            let optionsHTML = q.options.map((option, i) => `
                <label>
                    <input type="radio" name="answers[${index}]" value="${i}" required>
                    ${option}
                </label><br>
            `).join('');
            questionsHTML += `
                <div class="question">
                    <p>${q.id}. ${q.question}</p>
                    ${optionsHTML}
                </div>
            `;
        });

        
        testPage = testPage
            .replaceAll('<!--USER-->', user)
            .replace('<!--QUESTIONS-->', questionsHTML);
        res.send(testPage);
   
});


app.post('/results', async (req, res) => {
   
        const { user, score, total, answers } = req.results;

    
        if (user === '<!--USER-->') {
            throw new Error('Помилка: ім’я користувача не було замінено в /results');
        }

        let resultsPage = await fs.readFile(path.join(__dirname, 'pages', 'results.html'), 'utf-8');

    
        let answersHTML = '';
        answers.forEach((answer, index) => {
            let optionsHTML = answer.options.map((option, i) => {
                let className = '';
                if (i === answer.correctAnswer) className += 'correct-answer ';
                if (i === answer.userAnswer) className += 'user-answer ';
                return `<p class="${className.trim()}">${option}</p>`;
            }).join('');
            answersHTML += `
                <div class="result-question">
                    <p class="${answer.isCorrect ? 'correct' : 'incorrect'}">
                        ${index + 1}. ${answer.question}
                    </p>
                    ${optionsHTML}
                </div>
            `;
        });

        resultsPage = resultsPage
            .replaceAll('<!--USER-->', user)
            .replace('<!--SCORE-->', score)
            .replace('<!--TOTAL-->', total)
            .replace('<!--ANSWERS-->', answersHTML);

        res.send(resultsPage);
   
});

app.listen(PORT, () => {
    console.log(`Сервер запущено на http://localhost:${PORT}`);
});