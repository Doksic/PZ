const mongoose = require('mongoose');

   const vehicleSchema = new mongoose.Schema({
       name: { type: String, required: true },
       type: { type: String, required: true },
       status: { type: String, required: true },
       vehicleId: { type: Number, required: true, unique: true }
   });

   module.exports = mongoose.model('Vehicle', vehicleSchema);