const Vehicle = require('../models/Vehicle');

   exports.getAllVehicles = async (req, res) => {
       try {
           const vehicles = await Vehicle.find();
           res.json(vehicles);
       } catch (err) {
           res.status(500).json({ message: 'Помилка сервера' });
       }
   };

   exports.getVehicleById = async (req, res) => {
       try {
           const vehicle = await Vehicle.findById(req.params.id);
           if (!vehicle) return res.status(404).json({ message: 'Техніку не знайдено' });
           res.json(vehicle);
       } catch (err) {
           res.status(500).json({ message: 'Помилка сервера' });
       }
   };

   exports.createVehicle = async (req, res) => {
       try {
           const vehicle = new Vehicle(req.body);
           const newVehicle = await vehicle.save();
           res.status(201).json(newVehicle);
       } catch (err) {
           res.status(400).json({ message: 'Неправильні дані або ID вже існує' });
       }
   };

   exports.updateVehicle = async (req, res) => {
       try {
           const vehicle = await Vehicle.findById(req.params.id);
           if (!vehicle) return res.status(404).json({ message: 'Техніку не знайдено' });
           Object.assign(vehicle, req.body);
           const updatedVehicle = await vehicle.save();
           res.json(updatedVehicle);
       } catch (err) {
           res.status(400).json({ message: 'Неправильні дані' });
       }
   };

   exports.updateVehicleByVehicleId = async (req, res) => {
       try {
           const vehicle = await Vehicle.findOne({ vehicleId: parseInt(req.params.vehicleId) });
           if (!vehicle) return res.status(404).json({ message: 'Техніку не знайдено' });
           Object.assign(vehicle, req.body);
           const updatedVehicle = await vehicle.save();
           res.json(updatedVehicle);
       } catch (err) {
           res.status(400).json({ message: 'Неправильні дані' });
       }
   };

   exports.deleteVehicle = async (req, res) => {
       try {
           const vehicle = await Vehicle.findById(req.params.id);
           if (!vehicle) return res.status(404).json({ message: 'Техніку не знайдено' });
           await vehicle.remove();
           res.json({ message: 'Техніку видалено' });
       } catch (err) {
           res.status(500).json({ message: 'Помилка сервера' });
       }
   };