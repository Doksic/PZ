import chalk from 'chalk';
import player from 'play-sound';
import path from 'path';
import os from 'os';
import random from 'random';
import promptSync from 'prompt-sync'

//number1();
//number2();
//number3();  
//number4();

function number1(){
const error = chalk.bold.red;
const warning = chalk.hex('#FFA500'); 

console.log(error('Error!'));
console.log(warning('Warning!'));
}



function number2(){
const audioPlayer = player();

audioPlayer.play('W:/dowland/file.mp3', (err) => {
  if (err) {
    console.error('Помилка відтворення аудіо:', err);
  } else {
    console.log('Звук успішно відтворений!');
  }
});
}



function number3(){
  
  

  const filePath = 'file.txt';
  
  console.log('Повний шлях:', path.resolve(filePath));
  console.log('Назва файлу:', path.basename(filePath));
  console.log('Розширення файлу:', path.extname(filePath));
  console.log('Вид ОС:', os.type());


}

function number4(){
  const prompt = promptSync();
  let number = prompt('Введіть 1(Решка) або 2(Орел): ');
    if (number != 1 && number != 2) { 
      console.log('Ви ввели неправильне число');
      process.exit();
    } 

    let rannum = random.int(1,2);
    if(rannum == number){
      console.log('Ви виграли');
    } else {
      console.log('Ви програли');
    }

    if(rannum == 1 ) {
      rannum = 'Решка';
    }
    else {
      rannum = 'Орел';
    }
    console.log('Випало:', rannum);

    if(number == 1 ) {
      number = 'Решка';
    } else {
      number = 'Орел';
    } 
    console.log('Ви вибрали:', number);
    
  
  

}

