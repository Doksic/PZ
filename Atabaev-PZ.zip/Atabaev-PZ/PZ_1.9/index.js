 function weekday() {
const daysUA = {
   1:"Понеділок",
    2:"Вівторок",
    3:"Середа",
    4:"Четвер",
    5:"П'ятниця",
    6:"Субота",
    7:"Неділя"

  };
  
  const daysEN = {
    1:"Monday",
    2:"Tuesday",
    3:"Wednesday",
    4:"Thursday",
    5:"Friday",
    6:"Saturday",
    7:"Sunday"
  };
    let day = prompt("Choose language 'ua' or 'en'?");
    day = day.toLowerCase();
    if (day == "ua") {
        let dayNumber = prompt("Введіть номер дня тижня від 1 до 7:");
            if( isNaN(dayNumber) || dayNumber >0 || dayNumber < 8) {
                        alert(daysUA[dayNumber]);

            }
            else {
                alert("Некоректний число! Введіть число від 1 до 7.");
            }
    
        }
        else if (day !== "ua") {
            alert("Некоректана мова!");
        }

        else if (day == "en") {
            let dayNumber = prompt("Enter the day number of the week (from 1 to 7):");
            if( isNaN(dayNumber) || dayNumber >0 || dayNumber < 8) {
                alert(daysEN[dayNumber]);
            }
            else {
                alert("Invalid input! Enter a number from 1 to 7.");
            }
        }
        else {
            alert("Invalid language!");
        }

  }


  function chees() {
    const hOpt = {
        1: 1,
        2: 2,
        3: 3,
        4: 4,
        5: 5,
        6: 6,
        7: 7,
        8: 8,
    };

    const wOpt = {
        1: 1,
        2: 2,
        3: 3,
        4: 4,
        5: 5,
        6: 6,
        7: 7,
        8: 8,
    };


    let hNumber = prompt("Виберіть висоту дошки від 1 до 8:");
    let wNumber = prompt("Виберіть ширину дошки від 1 до 8:");

    const h = hOpt[hNumber];
    const w = wOpt[wNumber];


   
    function drawBoard() {
        let radok = ' ';
      
        for (let i = h; i >= 1; i--) {
            radok += i + ' ';
            for (let j = 0; j < w; j++) {
               
                radok += (i + j) % 2 === 0 ? '# ' : '@ ';
            }
            radok += '\n';
        }

  
        radok += '  ';
        for (let col = 0; col < w; col++) {
            radok += String.fromCharCode(65 + col) + ' '; // 65 - код літери A;
        }

        console.log(radok);
    }

    drawBoard();
}


class Random {
   
    static nextDouble(low, high) {
        
       let   result = low + Math.random() * (high - low);
        return result.toFixed(2);
    }

  
    static nextInt(low, high) {
        return Math.floor(low + Math.random() * (high - low + 1));
    }

   
    static nextElement(mac) {
        
        const index = Math.floor(Math.random() * mac.length);
        return mac[index];
    }
}

function randomNumbers() {
    console.log(Random.nextDouble(1.0, 5.0)); 
    console.log(Random.nextInt(1, 9)); 
    console.log(Random.nextElement([1, 2, 3,4,6,5,7,8])); 
}



function createGreetable(str) {
    
    const result = Object.create(createGreetable.prototype);
    result.value = str;
    return result;
}


createGreetable.prototype = {
    greet(greeting) {
        return `${greeting}, ${this.value}!`;
    },
    
    toString() {
        return this.value;
    }
};

function Oleg() {
const g = createGreetable('Oleg');
alert(g.greet('Hello')); 
};

function sequence(start = 0, step = 1) {
    // Створюємо об'єкт для зберігання стану
    const generator = {
        current: start,
        next() {
            const value = this.current;
            this.current += step;
            return value;
        }
    };
    
    return generator;
}

function number5() {
let generator = sequence(11, 10);
let generator2 = sequence(7, 7);

console.log(generator.next()); 
console.log(generator.next()); 
console.log(generator.next()); 
console.log(generator.next()); 
console.log(generator2.next()); 
console.log(generator2.next());
}



function pluck(array, field) {
    return array.map(obj => obj[field]);
}

let characters = [
    { name: "barney", age: 36 },
    { name: "fred", age: 40 },
    { name: "pebbles", age: 1 },
    { name: "wilma", age: 38 },
    { name: "betty", age: 35 },
    { name: "bamm-bamm", age: 5 },
    { name: "dino", age: 4 },
    { name: "scooby-doo", age: 7 }
];

console.log(pluck(characters, "name")); 

console.log(characters); 




//  weekday();
//  chees();
//randomNumbers();
// Oleg();
//number5();
//pluck(characters, "name");