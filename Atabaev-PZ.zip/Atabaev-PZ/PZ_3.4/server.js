const express = require('express');
const { MongoClient } = require('mongodb');
const cors = require('cors');
const app = express();
const port = 3000;


app.use(express.json());
app.use(cors());
app.use(express.static('.')); 


const uri = "mongodb://localhost:27017";
const client = new MongoClient(uri);
let collection;

async function connectToMongo() {
    try {
        await client.connect();
        const db = client.db("military");
        collection = db.collection("militaryUnit");
        console.log("Підключено до MongoDB");
    } catch (err) {
        console.error("Помилка підключення до MongoDB:", err);
    }
}

connectToMongo();


app.get('/personnel', async (req, res) => {
    try {
        const personnel = await collection.find().toArray();
        res.json(personnel);
    } catch (err) {
        res.status(500).send("Помилка при отриманні даних");
    }
});


app.post('/personnel', async (req, res) => {
    try {
        const newPerson = req.body;
        await collection.insertOne(newPerson);
        res.status(201).send("Військовослужбовця додано");
    } catch (err) {
        res.status(500).send("Помилка при додаванні");
    }
});


app.get('/personnel', async (req, res) => {
    try {
        const personnel = await collection.find().toArray();
    
        const sanitizedPersonnel = personnel.map(person => {
            return {
                ...person,
                _id: person._id.toString() 
            };
        });
        res.json(sanitizedPersonnel);
    } catch (err) {
        res.status(500).send("Помилка при отриманні даних");
    }
});

app.get('/personnel/:name', async (req, res) => {
    try {
        const person = await collection.findOne({ name: req.params.name });
        if (person) {
  
            const sanitizedPerson = {
                ...person,
                _id: person._id.toString()
            };
            res.json(sanitizedPerson);
        } else {
            res.status(404).send("Військовослужбовця не знайдено");
        }
    } catch (err) {
        res.status(500).send("Помилка при пошуку");
    }
});


app.delete('/personnel/:name', async (req, res) => {
    try {
        const result = await collection.deleteOne({ name: req.params.name });
        if (result.deletedCount > 0) {
            res.send("Військовослужбовця видалено");
        } else {
            res.status(404).send("Військовослужбовця не знайдено");
        }
    } catch (err) {
        res.status(500).send("Помилка при видаленні");
    }
});


app.put('/personnel/:name', async (req, res) => {
    try {
        const updatedData = req.body;
        const result = await collection.updateOne(
            { name: req.params.name },
            { $set: updatedData }
        );
        if (result.matchedCount > 0) {
            res.send("Дані оновлено");
        } else {
            res.status(404).send("Військовослужбовця не знайдено");
        }
    } catch (err) {
        res.status(500).send("Помилка при редагуванні");
    }
});


app.patch('/personnel/:name/unit-position', async (req, res) => {
    try {
        const { unit, position } = req.body;
        const result = await collection.updateOne(
            { name: req.params.name },
            { $set: { unit, position } }
        );
        if (result.matchedCount > 0) {
            res.send("Підрозділ та посада оновлені");
        } else {
            res.status(404).send("Військовослужбовця не знайдено");
        }
    } catch (err) {
        res.status(500).send("Помилка при редагуванні");
    }
});


app.listen(port, () => {
    console.log(`Сервер запущено на http://localhost:${port}`);
});