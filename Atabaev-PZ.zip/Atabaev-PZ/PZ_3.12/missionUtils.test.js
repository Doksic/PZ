const assert = require('assert');
const { calculateAmmoNeeded, isMissionReady } = require('./missionUtils');

describe('Тести', function() {
    it('Необхідна кількість патронів', function() {
        assert.strictEqual(calculateAmmoNeeded(10, 30), 300);
    });

    it('Достатньо патронів', function() {
        assert.strictEqual(isMissionReady(500, 300), true);
    });
    it('Патронів недостатньо', function() {
        assert.strictEqual(isMissionReady(200, 300), false);
    });
});