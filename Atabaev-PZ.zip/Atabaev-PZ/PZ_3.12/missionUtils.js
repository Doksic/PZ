function calculateAmmoNeeded(soldiers, roundsPerSoldier) {
    return soldiers * roundsPerSoldier;
}

function isMissionReady(ammoAvailable, ammoNeeded) {
    return ammoAvailable >= ammoNeeded;
}

module.exports = { calculateAmmoNeeded, isMissionReady };